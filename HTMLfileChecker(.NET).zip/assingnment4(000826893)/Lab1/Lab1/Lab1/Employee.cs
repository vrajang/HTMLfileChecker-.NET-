﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// This class describes the employee
/// </summary>
public class Employee : IComparable<Employee>
{
  private string name;                          // The employee name
  private int number;                           // The employee ID
  private decimal rate;                         // The hourly rate
  private double hours;                         // The weekly hours
  private decimal gross;                        // The gross pay



    /// <summary>
    ///  constructor for Employee
    /// </summary>
    /// <param name="name">Employee name</param>
    /// <param name="number">Employee number</param>
    /// <param name="rate">Hourly rate of pay</param>
    /// <param name="hours">Hours worked in a week</param>
    public Employee(string name, int number, decimal rate, double hours)
    {
        this.name = name;
        this.number = number;
        this.rate = rate;
        this.hours = hours;
        CalcGross();
    }

    /// Gross pay property
    public decimal Gross
    {
        get { return gross; }
        set { gross = value; }
    }

    /// Hours property
    public double Hours
    {
        get { return hours; }
        set { hours = value; CalcGross(); }
    }
    /// Name property
    public string Name
    {
        get { return name; }
        set { name = value; }
    }
    /// Employee number property
    public int Number
    {
        get { return number; }
        set { number = value; }
    }
    /// Hourly rate property
    public decimal Rate
    {
        get { return rate; }
        set { rate = value; CalcGross(); }
    }
   //calculate the gross pay including the over time 
    private void CalcGross()
    {
        if (hours <= 40)
        {
            gross = rate * (decimal)hours;
        }
        else
        {
            double bonus;
            bonus = ((hours - 40) * 0.5) + (hours - 40);
            gross = (rate * 40) + (rate * (decimal)bonus);
        }
    }
    //methos to print the whole employee data 
    public void PrintEmployee()
    {
        System.Console.WriteLine("Name: " + name);
        System.Console.WriteLine("Number: " + number);
        System.Console.WriteLine("Rate of Pay: " + rate);
        System.Console.WriteLine("Hours: " + hours);
        System.Console.WriteLine("Gross Pay: " + gross);
    }
    
    // Implemented CompareTo method from the IComparable interface.  Compares values between employee
    // objects.
    
    
    public int CompareTo(Employee emp)
    {
        if (emp == null)
        {
            return 1;
        }

        int result = 0;

        // Compare names
        result = this.name.CompareTo(emp.name);
        if (result != 0)
        {
            return result;
        }

        // Compare employee numbers
        result = this.number.CompareTo(emp.number);
        if (result != 0)
        {
            return result;
        }

        // Compare pay rates
        result = emp.rate.CompareTo(this.rate);
        if (result != 0)
        {
            return result;
        }

        // Compare hours worked
        result = emp.hours.CompareTo(this.hours);
        if (result != 0)
        {
            return result;
        }

        // Compare gross pay
        result = emp.gross.CompareTo(this.gross);
        if (result != 0)
        {
            return result;
        }
        return result;
    }

}


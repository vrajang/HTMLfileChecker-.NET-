﻿///Statement of Authorship: I, vrajang shah, 000826839 certify that this material is my original work. No other 
///person's work has been used without due acknowledgement.
///This form us eto validate the the user html file like if the user is missing any html tags 
///it will show bad file test or else it show its goood 
///what you have to do is just select the file form the file tag and click on the check button 
///all the tags will be lised in list box and if the file is not proper then top label will show bad file or else balanced
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace part2
{
    public partial class Form1 : Form
    {
        string filePath; //String used for filepath
        bool validFileLoaded = false; //Boolean value used for making sure the 'Check Tags' button can/can't be used
        List<string> fileContent = new List<string>(); //Contains all the raw HTML file content
        List<string> htmlTags = new List<string>(); //Contains opening and closing tags

        public Form1()
        {
            InitializeComponent();
        }
        /// Verifies if there is a proper loaded file.
        private void verifyLoadedFile()
        {
            if (validFileLoaded)
            {
                checkTagsToolStripMenuItem.Enabled = true;
            }
            else
            {
                checkTagsToolStripMenuItem.Enabled = false;
            }
        }
        // streamreader which reads the whole file
        public void ReadFile(string filePath)
        {
            fileContent.Clear();
            string line;
            using (StreamReader sr = new StreamReader(filePath))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    fileContent.Add(line);
                }
            }
        }
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void oPENFILEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Filters only HTML files when you try to select
            openFileDialog1.Filter = ".HTML files (*.html)|*.html";
            openFileDialog1.FilterIndex = 1;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Checks to see if the file selected is actually a valid .html file 
                //works like exception handiling 
                if (Path.GetExtension(openFileDialog1.FileName) == ".html")
                {
                    filePath = openFileDialog1.FileName;
                    messageLabel.Text = "Loaded: " + openFileDialog1.FileName;
                    validFileLoaded = true;
                    verifyLoadedFile();
                }
                //Throws an error message if the file is not a valid .html file and resets.
                else
                {
                    messageLabel.Text = "No file loaded; load a file by using File --> Open File";
                    MessageBox.Show("Invalid file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    validFileLoaded = false;
                    verifyLoadedFile();
                }
            }
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }
        //this check the each and every tags in the html file 
        private void cHECKTAGSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fileListBox.Items.Clear();
            fileContent.Clear();
            ReadFile(filePath);
            foreach (string s in fileContent)
            {
                ProcessHTML(s);
            }

            if (CheckTags(htmlTags))
            {
                messageLabel.Text = openFileDialog1.SafeFileName + " has balanced HTML tags.";
            }
            else messageLabel.Text = openFileDialog1.SafeFileName + " does not have balanced HTML tags.";
        }
        //check the selected html file 
        public void ProcessHTML(string html)
        {

            //Self explanatory - if the line isn't there, don't return anything.
            if (String.IsNullOrWhiteSpace(html))
            {
                return;
            }

            //Looks through the entire string
            for (int i = 0; i < html.Length; i++)
            {
                //Checks to see if an open bracket is found
                if (html[i] == '<')
                {
                    int j = i;
                    string tag = "";
                    do
                    {
                        tag += html[j];
                        j++;
                    } while (html[j - 1] != '>');

                    //Checks to make sure the tags aren't non-container elements
                    if (!(tag.Contains("img") || tag.Contains("<hr>") || tag.Contains("br")))
                    {
                        if (tag[1].Equals('/'))
                        {
                            fileListBox.Items.Add("Found closing tag: " + tag);
                            htmlTags.Add(tag.ToLower()); //Adds closed tag element to the list (lowercase) for testing balance
                        }
                        else
                        {
                            fileListBox.Items.Add("Found opening tag: " + tag);
                            if (tag.Contains(" "))
                            {
                                tag = tag.Remove(tag.IndexOf(" ")) + ">";
                            }
                            htmlTags.Add(tag.ToLower()); //Adds open-tagged element to the list (lowercase) for testing balance
                        }
                    }
                    //If they are non-container elements, just display them
                    else
                    {
                        fileListBox.Items.Add("Found non-container tag: " + tag); //DOES NOT add non-container tag to the list
                    }
                }
            }
        }

        //check tags method
        public bool CheckTags(List<string> tags)
        {
            //Initial boolean value; set to 'true' by default in-case an empty HTML page is given.
            bool balanced = true;

            //Trim conditions for checking the inside of tags
            char[] trimConditions = { '<', '/', '>' };
            //Empty stack; used to store (open) HTML tags
            Stack<string> htmlTagStack = new Stack<string>();

            //For-loop; runs through the list of HTML tags
            for (int i = 0; i < tags.Count; i++)
            {
                //Temporary bool value - used to see if the current element is open or closed-tagged
                bool isOpen;
                //Temporary string value - used to see inner tag values without closing brackets (<, / or >)
                string tempString = tags.ElementAt(i).Trim(trimConditions);

                //Checks to see if the current element is an open or closed-tagged element
                if (tags.ElementAt(i)[1].Equals('/'))
                {
                    isOpen = false;
                }
                else isOpen = true;

                //If it is an open-tagged element, push it to the stack
                if (isOpen)
                {
                    htmlTagStack.Push(tags.ElementAt(i));
                }
                //If it is a closed-tagged element, check the inner contents. If it is the same as
                //the last element of the stack, pop the stack and continue
                else
                {
                    if (htmlTagStack.Peek().Trim(trimConditions).Equals(tempString))
                    {
                        htmlTagStack.Pop();
                    }
                    //If it is not the same, the HTML page is not balanced.
                    else
                    {
                        balanced = false;
                    }
                }
            }
            return balanced;
        }

        private void fileListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void messageLabel_Click(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
